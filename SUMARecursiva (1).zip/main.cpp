//Este es un programa para calcular la suma con metodo recursivo desde el 1 hasta n; n lo vamos a manejar como un imput.
//Ricardo Uraga de la Fuente A01028921
//Fecha creación : 26/08/2020
//Complejidad O(n)

#include <iostream>
using namespace std;


int sumaRecursiva(int num){
    if(num==0){
        return 0;
    }
    if(num>0){
        return sumaRecursiva(num-1) + num;
    }
}

int main(){
    int numero;
    cout<<"Ingresa un numero"<<endl;
    cin>>numero;
    cout<<"La suma de los digitos de 1 hasta n es : "<<sumaRecursiva(numero)<<endl;
    cout<<"Ejemplo 1   "<<sumaRecursiva(4)<<endl;
    cout<<"Ejemplo 2   "<<sumaRecursiva(6)<<endl;
    cout<<"Ejemplo 3   "<<sumaRecursiva(7)<<endl;
}
