//Este es un programa para calcular la suma con metodo directo desde el 1 hasta n; n lo vamos a manejar como un imput.
//Ricardo Uraga de la Fuente A01028921
//Fecha creación : 26/08/2020
//complejidad O(1)

#include <iostream>
using namespace std;

long int metodoDirecto (long int n)
{
 return (n*(n+1))/2;
}
int main (){
  long int numero;
  cout<<" ingresa un numero  "<<endl;
  cin >>numero;
  cout <<"El metodo directo es  "<<metodoDirecto(numero)<<endl;

  cout<<"Ejemplo 1...."<<metodoDirecto(4)<<endl;
  cout<<"Ejemplo 2...."<<metodoDirecto(6)<<endl;
  cout<<"Ejemplo 3...."<<metodoDirecto(7)<<endl;
}