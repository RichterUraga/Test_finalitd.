#include <iostream>
#include <vector>
#include<stdlib.h>
#include <chrono>
#include "sorter.h"
using namespace std;
using namespace std::chrono;

template <typename T>
void print_vec(vector<T>arr,int N)
{
  for(size_t i =0 ; i <arr.size()&&i<N; i++)
  {
    cout<<arr[i]<<",";

  }
  cout<<endl;
}
int main (){

  vector<int>arr_f;
  int count=10;
  for (size_t i = 0 ; i<count; i++)
  {
    arr_f.push_back((int)rand()%256);

  }
  BubbleSort<int>bubblesortt;
  bubblesortt.sort(arr_f);

  SelectionSort<int>selsort;
  selsort.sort(arr_f);
  cout<<endl<<"Sorted"<<endl;
  print_vec(arr_f,10);
  return 0;

}
