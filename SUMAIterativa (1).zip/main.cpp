//Este es un programa para calcular la suma con metodo iterativo desde el 1 hasta n; n lo vamos a manejar como un imput.
//Ricardo Uraga de la Fuente A01028921
//Fecha creación : 26/08/2020
//Complejidad O(n)
#include <iostream>
using namespace std;
int sumaIterativa(int num){
    //declaramos suma
    int suma;
    for(int i = 0; i < num; i++){
        suma = suma + i +1;
    }
    //retornamos el valor de suma
    return suma;
}
int main(){
    int numero;
    cout<<"Ingresa un número"<<endl;
    cin>>numero;
    cout<<"La suma de los números es : "<<sumaIterativa(numero)<<endl;
    cout<<"Ejemplo 1...."<<sumaIterativa(4)<<endl;
    cout<<"Ejemplo 2...."<<sumaIterativa(6)<<endl;
    cout<<"Ejemplo 3...."<<sumaIterativa(7)<<endl;
}

